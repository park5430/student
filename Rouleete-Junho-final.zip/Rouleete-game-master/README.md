### 룰렛 게임 만들기
 - http://dougtesting.net/winwheel/docs/tut1_getting_started